package com.voidglass.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;

public class SettingsActivity extends Activity {
    LinearLayout r;
    SharedPreferences s;

    public void onCreate(Bundle b){
        super.onCreate(b);
        s=getSharedPreferences("void",0);
        build();
    }

    TextView t(String x,int z){
        TextView v=new TextView(this);
        v.setText(x);
        v.setTextColor(Color.WHITE);
        v.setTextSize(z);
        v.setPadding(20,14,20,8);
        return v;
    }

    void build(){
        ScrollView sv=new ScrollView(this);
        r=new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(10,16,10,24);
        r.setBackgroundColor(0xff060912);

        r.addView(t("Void Glass Settings",26));
        r.addView(t("🎨 Appearance",16));
        seek("Icon size",70,80,76,"icon");
        sw("Icon labels",true,"labels");
        seek("Grid columns",5,6,5,"grid");
        seek("Icon spacing",0,30,8,"spacing");
        seek("Wallpaper dim",30,40,35,"dim");

        r.addView(t("🫧 Glass effect",16));
        seek("Transparency",60,75,72,"trans");
        seek("Blur",70,90,82,"blur");
        seek("Corner radius",20,40,34,"radius");
        seek("Shadow",0,30,8,"shadow");
        seek("Accent glow",0,30,8,"glow");

        r.addView(t("🏠 Home screen",16));
        sw("Minimal widgets",true,"widgets");
        sw("Large simple clock",true,"clock");
        sw("Hide app names",false,"hideLabels");

        r.addView(t("📦 App drawer",16));
        seek("Drawer columns",5,6,5,"drawerCols");
        sw("Alphabetical sorting",true,"alpha");
        sw("Fade / slide animation",true,"anim");

        r.addView(t("⚡ Premium",16));
        sw("Haptic feedback",true,"haptic");
        sw("Monochrome icons",false,"mono");

        Button b=new Button(this);
        b.setText("🖼  Choose wallpaper from Gallery");
        b.setOnClickListener(v->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                       Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i,9);
        });
        r.addView(b);

        Button reset=new Button(this);
        reset.setText("↺  Use current system wallpaper");
        reset.setOnClickListener(v->{
            s.edit().remove("wallpaperUri").apply();
            Toast.makeText(this,"System wallpaper digunakan",Toast.LENGTH_SHORT).show();
            finish();
        });
        r.addView(reset);

        r.addView(t("Wallpaper is used inside Void Glass; it does not need to replace your phone's wallpaper.",12));
        sv.addView(r);
        setContentView(sv);
    }

    void sw(String x,boolean d,String k){
        Switch q=new Switch(this);
        q.setText(x);
        q.setTextColor(Color.WHITE);
        q.setPadding(20,8,20,8);
        q.setChecked(s.getBoolean(k,d));
        q.setOnCheckedChangeListener((b,c)->s.edit().putBoolean(k,c).apply());
        r.addView(q);
    }

    void seek(String x,int mn,int mx,int d,String k){
        TextView q=t(x+"  "+s.getInt(k,d),13);
        SeekBar b=new SeekBar(this);
        b.setMax(mx-mn);
        b.setProgress(s.getInt(k,d)-mn);
        b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar z,int p,boolean f){
                int v=p+mn;
                q.setText(x+"  "+v);
                s.edit().putInt(k,v).apply();
            }
            public void onStartTrackingTouch(SeekBar z){}
            public void onStopTrackingTouch(SeekBar z){}
        });
        r.addView(q);
        r.addView(b);
    }

    public void onActivityResult(int rq,int rc,Intent d){
        super.onActivityResult(rq,rc,d);
        if(rq==9&&rc==RESULT_OK&&d!=null&&d.getData()!=null){
            try{
                Uri u=d.getData();
                final int flags=Intent.FLAG_GRANT_READ_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(u,flags);
                s.edit().putString("wallpaperUri",u.toString()).apply();
                Toast.makeText(this,"Wallpaper Void Glass ditukar",Toast.LENGTH_SHORT).show();
                finish();
            }catch(Exception e){
                Toast.makeText(this,"Tak dapat pilih wallpaper",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
