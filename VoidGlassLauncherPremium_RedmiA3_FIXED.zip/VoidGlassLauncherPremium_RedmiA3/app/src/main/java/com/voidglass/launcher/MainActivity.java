package com.voidglass.launcher;

import android.app.Activity;
import android.app.WallpaperManager;
import android.os.Bundle;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import java.io.InputStream;
import java.util.*;

public class MainActivity extends Activity {
    V v;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
        v = new V();
        setContentView(v);
    }

    @Override public void onResume() {
        super.onResume();
        if (v != null) { v.load(); v.loadWallpaper(); v.invalidate(); }
    }

    class A {
        String n; Drawable i; Intent x;
        A(String n, Drawable i, Intent x) { this.n=n; this.i=i; this.x=x; }
    }

    class V extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<A> a = new ArrayList<>();
        SharedPreferences s;
        Bitmap wallpaper;
        float downX, downY;
        int page=0, cols=5, rows=7;

        V() {
            super(MainActivity.this);
            s = getSharedPreferences("void",0);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            load();
            loadWallpaper();
        }

        void load() {
            a.clear();
            PackageManager m=getPackageManager();
            Intent q=new Intent(Intent.ACTION_MAIN);
            q.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> z=m.queryIntentActivities(q,0);
            Collections.sort(z,(u,w)->u.loadLabel(m).toString().compareToIgnoreCase(w.loadLabel(m).toString()));
            for (ResolveInfo r:z) {
                if (r.activityInfo.packageName.equals(getPackageName())) continue;
                Intent x=new Intent(Intent.ACTION_MAIN);
                x.addCategory(Intent.CATEGORY_LAUNCHER);
                x.setClassName(r.activityInfo.packageName,r.activityInfo.name);
                a.add(new A(r.loadLabel(m).toString(),r.loadIcon(m),x));
            }
        }

        void loadWallpaper() {
            if (wallpaper != null) { wallpaper.recycle(); wallpaper=null; }
            String uriString=s.getString("wallpaperUri", "");
            try {
                if (!uriString.isEmpty()) {
                    Uri u=Uri.parse(uriString);
                    InputStream in=getContentResolver().openInputStream(u);
                    wallpaper=BitmapFactory.decodeStream(in);
                    if (in!=null) in.close();
                }
                if (wallpaper==null) {
                    Drawable d=WallpaperManager.getInstance(MainActivity.this).getDrawable();
                    if (d!=null) {
                        int w=Math.max(1,d.getIntrinsicWidth()), h=Math.max(1,d.getIntrinsicHeight());
                        Bitmap b=Bitmap.createBitmap(Math.min(w,1600),Math.min(h,3200),Bitmap.Config.ARGB_8888);
                        Canvas cc=new Canvas(b);
                        d.setBounds(0,0,b.getWidth(),b.getHeight());
                        d.draw(cc);
                        wallpaper=b;
                    }
                }
            } catch(Exception ignored) {}
        }

        @Override protected void onDraw(Canvas c) {
            int w=getWidth(), h=getHeight();

            // Wallpaper
            p.setShader(null);
            if (wallpaper != null && !wallpaper.isRecycled()) {
                RectF dst=new RectF(0,0,w,h);
                float scale=Math.max(w/(float)wallpaper.getWidth(), h/(float)wallpaper.getHeight());
                float dw=wallpaper.getWidth()*scale, dh=wallpaper.getHeight()*scale;
                dst.set((w-dw)/2f,(h-dh)/2f,(w+dw)/2f,(h+dh)/2f);
                c.drawBitmap(wallpaper,null,dst,p);
            } else {
                p.setShader(new LinearGradient(0,0,w,h,
                    new int[]{0xff03050b,0xff101a2e,0xff05070d},null,Shader.TileMode.CLAMP));
                c.drawRect(0,0,w,h,p);
            }

            // Premium dark veil / wallpaper dim
            int dim=Math.max(0,Math.min(80,s.getInt("dim",35)));
            p.setColor(Color.argb((int)(255*dim/100f),0,0,0));
            c.drawRect(0,0,w,h,p);

            // Subtle void glow
            p.setColor(0x2870dfff);
            p.setMaskFilter(new BlurMaskFilter(75,BlurMaskFilter.Blur.NORMAL));
            c.drawCircle(w*.82f,h*.18f,130,p);
            p.setMaskFilter(null);

            // Clock + launcher title
            p.setShader(null);
            p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(20);
            p.setColor(Color.WHITE);
            c.drawText(time(),20,35,p);
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(11);
            p.setColor(0xccffffff);
            c.drawText("Void Glass",20,54,p);

            // Search / settings glass bar
            glass(c,15,67,w-15,111,25);
            p.setTextSize(12);
            p.setColor(0xeeffffff);
            c.drawText("⌕  Search apps",31,95,p);
            p.setTextSize(10);
            p.setColor(0x99ffffff);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("⚙",w-31,95,p);
            p.setTextAlign(Paint.Align.LEFT);

            float cw=w/(float)cols, top=127, ch=68;
            int size=(int)(46*s.getInt("icon",76)/100f);
            int start=page*cols*rows;

            for(int i=0;i<cols*rows;i++){
                int k=start+i;
                if(k>=a.size()) break;
                int co=i%cols, ro=i/cols;
                float x=cw*co+cw/2, y=top+ro*ch+27;
                icon(c,a.get(k).i,x,y,size);
                if(!s.getBoolean("hideLabels",false)){
                    p.setTextAlign(Paint.Align.CENTER);
                    p.setTextSize(9);
                    p.setColor(0xddffffff);
                    String n=a.get(k).n;
                    if(n.length()>10)n=n.substring(0,9)+"…";
                    c.drawText(n,x,y+size/2+14,p);
                    p.setTextAlign(Paint.Align.LEFT);
                }
            }

            int pages=Math.max(1,(a.size()+cols*rows-1)/(cols*rows));
            for(int i=0;i<pages;i++){
                p.setColor(i==page?Color.WHITE:0x55ffffff);
                c.drawCircle(w/2f+(i-(pages-1)/2f)*11,h-101,3,p);
            }

            // Glass dock
            glass(c,14,h-83,w-14,h-14,29);
            int d=Math.min(5,a.size());
            for(int i=0;i<d;i++) icon(c,a.get(i).i,14+(w-28)*(i+.5f)/d,h-48,37);
        }

        String time(){
            Calendar z=Calendar.getInstance();
            return String.format(Locale.getDefault(),"%02d:%02d",
                z.get(Calendar.HOUR_OF_DAY),z.get(Calendar.MINUTE));
        }

        void glass(Canvas c,float l,float t,float r,float b,float rad){
            int alpha=Math.max(25,Math.min(220,s.getInt("trans",72)));
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(alpha,255,255,255));
            c.drawRoundRect(l,t,r,b,rad,rad,p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0x4affffff);
            p.setStrokeWidth(1);
            c.drawRoundRect(l,t,r,b,rad,rad,p);
            p.setStyle(Paint.Style.FILL);
        }

        void icon(Canvas c,Drawable d,float x,float y,int z){
            float l=x-z/2f,t=y-z/2f;
            p.setColor(0x35ffffff);
            c.drawRoundRect(l,t,l+z,t+z,14,14,p);
            d.setBounds((int)l+3,(int)t+3,(int)l+z-3,(int)t+z-3);
            d.draw(c);
        }

        public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                downX=e.getX(); downY=e.getY(); return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getX()-downX, dy=e.getY()-downY;
                if(Math.abs(dx)>70 && Math.abs(dx)>Math.abs(dy)){
                    int pages=Math.max(1,(a.size()+cols*rows-1)/(cols*rows));
                    if(dx<0&&page<pages-1)page++;
                    if(dx>0&&page>0)page--;
                    invalidate(); return true;
                }
                // Open settings from the glass search/header area
                if(e.getY()<115 && e.getY()>60){
                    startActivity(new Intent(MainActivity.this,SettingsActivity.class));
                    return true;
                }
                int w=getWidth(), h=getHeight();
                if(e.getY()>127 && e.getY()<h-90){
                    int co=(int)(e.getX()/(w/(float)cols));
                    int ro=(int)((e.getY()-127)/68);
                    int k=page*cols*rows+ro*cols+co;
                    if(co>=0&&co<cols&&ro>=0&&ro<rows&&k<a.size()){
                        startActivity(a.get(k).x);
                        if(s.getBoolean("haptic",true))
                            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    }
                }
                return true;
            }
            return true;
        }
    }
}
