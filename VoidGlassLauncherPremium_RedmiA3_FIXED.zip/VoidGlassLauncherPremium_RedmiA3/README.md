# Void Glass Launcher Premium — Redmi A3

Void-style Android launcher with:
- 5×7 compact grid
- smaller rounded icons
- translucent glass panels and dock
- launcher HOME intent so it can be selected as the default launcher
- wallpaper picker that changes the wallpaper **inside the launcher**
- persistent selected wallpaper
- system-wallpaper fallback
- haptic feedback
- dark premium UI
- `armeabi-v7a` ABI filter for the Redmi A3 build target

## Build
Push the project to GitHub and run **Actions → Build Void Glass Launcher APK**.
The generated `app-debug.apk` is uploaded as a workflow artifact.
