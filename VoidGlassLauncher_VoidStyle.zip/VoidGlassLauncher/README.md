# Void Glass Launcher

Launcher Android gaya Void: tema gelap/merah, carian app, grid 5 kolum, buka app dengan tap, dan pilihan wallpaper dari Gallery/Files.

Build dengan Java 17 + Gradle 8.9+:
`gradle clean assembleDebug`
